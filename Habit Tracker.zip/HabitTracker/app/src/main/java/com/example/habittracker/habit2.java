package com.example.habittracker;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;



import java.util.Calendar;


import android.os.Bundle;
import android.widget.Toast;

public class habit2 extends AppCompatActivity implements
        DatePickerDialog.OnDateSetListener
{
    TextView t1,t2,t3;
    EditText e1,e2;
    Button b1,b2,b3;
    String days[] = {"Sunday", "Monday", "Tuesday","Wednesday","Thursday","Friday","Saturday"};
    Spinner sp1,sp2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_habit2);
        t1 = (TextView) findViewById(R.id.tv);
        t2 = (TextView) findViewById(R.id.tv_dateSelected);
        t3 = (TextView) findViewById(R.id.tv_timeSelected);
        e1 = (EditText) findViewById(R.id.et_habitTitle);
        e2 = (EditText) findViewById(R.id.et_habitDescription);
        b1 = (Button) findViewById(R.id.btn_pickDate);
        b2 = (Button) findViewById(R.id.btn_pickTime);
        b3 = (Button) findViewById(R.id.btn_confirm);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar c = Calendar.getInstance();
                int year = c.get(Calendar.YEAR);
                int month = c.get(Calendar.MONTH);
                int day = c.get(Calendar.DAY_OF_MONTH);
                Log.d("MainActivity", "" + c.get(Calendar.DATE));
                Log.d("MainActivity", "year = " + year +
                        " month = " + month +
                        " day = " + day);
                DatePickerDialog datePickerDialog = new DatePickerDialog(habit2.this, habit2.this, year, month, day);
                datePickerDialog.show();
 /* if (android.os.Build.VERSION.SDK_INT >=
android.os.Build.VERSION_CODES.N) {
 DatePickerDialog datePickerDialog1 = new
DatePickerDialog(MainActivity.this);
 }*/

            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            Calendar c = Calendar.getInstance();
            int hour = c.get(Calendar.HOUR);
            int minute = c.get(Calendar.MINUTE);

            @Override
            public void onClick(View view) {
                TimePickerDialog timePicker = new TimePickerDialog(habit2.this,
                        (timePicker1, i, i1) -> {
                            Log.d("MainActivity", "Got time - " + i + "-" + i);
                            t3.setText(i + ":" + i1);
                        },
                        hour, minute, true);
                timePicker.show();
            }
        });
        b3.setOnClickListener(v -> {
            if (e1.getText().toString().length() == 0) {
                e1.setError("Habit not entered");
                e1.requestFocus();
            }
            if (e2.getText().toString().length() == 0) {
                e2.setError("Description not entered");
                e2.requestFocus();
            }
           /* if (t2.getText().toString().equals("(not selected)")) {
                t2.setError("Date not selected");
                t2.requestFocus();
            }
            if (t3.getText().toString().equals("(not selected)")) {
                t3.setError("Time not selected");
                t3.requestFocus();
            }*/
            else {
                Intent ha=new Intent(getApplicationContext(),habits.class);
                startActivity(ha);

            }
        });
    }
    @Override
    public void onDateSet(DatePicker datePicker, int year, int month, int date) {
        Log.d("MainActivity","Got date - "+ year+"-"+(month+1)+"-"+date);
        t2.setText(year+"-"+(month+1)+"-"+date);
    }
}




