package com.example.habittracker;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.util.Pair;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.DatePicker;
import android.widget.TextView;
import java.util.Calendar;
import java.util.Date;
import android.widget.Toast;

import com.google.android.material.datepicker.MaterialDatePicker;
import com.squareup.timessquare.CalendarPickerView;

import java.util.Calendar;
import java.util.List;


public class calendar extends AppCompatActivity {

    CalendarPickerView calendarPickerView;
    Button b2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendar);

        Date today = new Date();
        b2=findViewById(R.id.button2c);
        calendarPickerView = findViewById(R.id.calendar);
        Calendar nextYear = Calendar.getInstance();

        nextYear.add(Calendar.YEAR, 1);
        calendarPickerView.init(today, nextYear.getTime())
                .inMode(CalendarPickerView.SelectionMode.RANGE);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent ic=new Intent(getApplicationContext(),habits.class);
                startActivity(ic);
            }
        });
    }

    public void displayDates(View view) {
        List<Date> dates =  calendarPickerView.getSelectedDates();

        for(Date i : dates){
            Toast.makeText(this, i.toString(), Toast.LENGTH_SHORT).show();
        }
    }
}

