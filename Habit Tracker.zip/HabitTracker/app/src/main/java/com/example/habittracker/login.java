package com.example.habittracker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class login extends AppCompatActivity {
    TextView loginbtn;
    EditText ea;
    EditText pwd;
    int c=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        loginbtn=findViewById(R.id.lgnbt);
        ea=findViewById(R.id.editTextTextEmailAddress);
        loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(TextUtils.isEmpty(ea.getText())){
                    ea.setError( "Email is required!" );


                }

                    else{

                        Intent i2 = new Intent(getApplicationContext(), habits.class);
                        startActivity(i2);

                    }
                }

        });
    }
}